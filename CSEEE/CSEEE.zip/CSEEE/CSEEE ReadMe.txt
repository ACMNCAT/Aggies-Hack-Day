The purpose for this project was to create a website to connect
the students of the 5th floor of McNair Hall at NCAT.  This was
my first working with HTML in a while and I started this project 
using Notepad++.  

My website design for this project is far from being completed 
there are quite a few problems that I will need to fix before it
is completed:

*I should look into a different template or backgoud image
for the background because there is a clash between it and the
letters.  I would like to make it pictures of the offices of 
the different departments or a collage of the 5th floor students.
*It needs a scroll bar for the registration page and the profile
page.  When I put one in it didn't work completly.  I think it 
had something to do the CSS.
*I couldn't figure out how to get the information from the input
field into the profile page
*And I also need to figure out how to change the color of the 
submit button on the sign-in page.

If you have any suggestions on how I can improve this
feel free to email me at jnander1@aggies.ncat.edu

Thanks for reading,
Jessica Anderson